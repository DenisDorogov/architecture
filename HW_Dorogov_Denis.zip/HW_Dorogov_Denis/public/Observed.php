<?php

interface Observed
{
 function notifyApplicant($data);
}